package ir2;
import java.io.*;
import java.util.*;
import java.lang.Math;
//Sarfaraz Ali Memon 
//k164051

public class IR2{
    public static void main(String[] args) throws Exception{
        int N=50;                                   //Total No of total Documents
        HashMap<String,int[][]> map = new HashMap<String,int[][]>(); //For Dictionary
        File dir=new File("stories");
        File[] listOfFiles = dir.listFiles();
        String word;
        int t;
        List<String> stopwords =Arrays.asList("a","is","the","of","all","and","to","can","be","as","once","for","at","am","are","has","have","had","up","his","her","in","on","no","we","do");
        for (File file : listOfFiles) 
        {
            StreamTokenizer token = new StreamTokenizer(new BufferedReader(new FileReader(file)));
            String[] te=file.getName().split("[.]");                        //Converting name of file from String to Integer..
            int doc_id=Integer.parseInt(te[0]);                                 //typecasting of string to int..
            token.whitespaceChars(' ' , '.');
            while ((t = token.nextToken()) != StreamTokenizer.TT_EOF) 
            {
                if (token.sval!=null)
                {         
                    word=token.sval.toLowerCase();
                    if(word.length()<5)                                 //comparing only those words with Stopwords whose length is less than 4//
                    {
                        if(stopwords.contains(word))
                        continue;
                    }
                    String[] tokens=word.split("[[,] ['] [:] [;] [!] [?] [-] [.] [\"] ]");
                    for(String str:tokens)
                    {
                        if(str.length()>1)
                        { 
                            if(map.get(str)==null){
                                    int[][] arrli=new int[50][1];
                                    arrli[doc_id - 1][0]=1;
                                    map.put(str,arrli);
                                    
                            }
                            else{
                                int[][] arrli;
                                arrli=map.get(str);
                                arrli[doc_id - 1][0]++;
                                map.put(str, arrli);
                            }
                        }
                    }
                }
            }
        }
        
        Scanner s=new Scanner(System.in);
        System.out.println("\n\n\t------------------------------------");
        System.out.print("\tENTER THE QUERY-->  ");
        String query=s.nextLine();
        System.out.print("\t----------------------------");
        EvaluateQuery(query,map);
        
}
public static void EvaluateQuery(String query,Map<String ,int[][]> map)
    {   
        double alpha= 0.005,query_mag=0,N=50; //total documents in Corpus.....
        System.out.println("\n\nENTERED QUERY IS ----> "+query);
        System.out.println("-------------------------------------------------------------------");
        query=query.toLowerCase();
        StringTokenizer st1 =new StringTokenizer(query);   //tokenization of user entered query
        
        ArrayList<String> query_terms=new ArrayList<String>();
        ArrayList<Integer> query_tf=new ArrayList<Integer>();
        
            while (st1.hasMoreTokens()){ //saving distinct tokens of query  into array list 
            String   cpy=st1.nextToken();
                if(!query_terms.contains(cpy)){
                    query_terms.add(cpy);
                    query_tf.add(1);
                }
                else if(query_terms.contains(cpy)){
                    int x=query_terms.indexOf(cpy);
                    query_tf.add(x, query_tf.get(x) +1);
                    query_tf.remove(x+1);
                }

            }    
        int count=0;
        int[][] w;                                          //temperory array 
        double[][] tf_cross_idf=new double[map.size()][50];   //TF * IDF for Documents 
        double[][] query_tf_idf=new double[map.size()][1];   //TF * IDF for Query Terms
        double[] magnitude=new double[50];                   //Array To Store The Magnitudes of the Docments               
        
        for(Map.Entry entry:map.entrySet())
        {
            
            String t=(String)entry.getKey();
            double idf=Math.log10(N/finddf(t,map));         //Calculating Idf Here
            w=map.get(t);
    
            for(int j=0;j<50;j++)                       
            {
                tf_cross_idf[count][j] =  w[j][0] * idf ;
                if(tf_cross_idf[count][j]!=0)
                magnitude[j] += (tf_cross_idf[count][j]*tf_cross_idf[count][j]);
            }
            
            if(query_terms.contains(t))
            {
                query_tf_idf[count][0] = query_tf.get(query_terms.indexOf(t)) * idf ;
                query_mag += (query_tf_idf[count][0] * query_tf_idf[count][0]);
            }
            else
            {
                    query_tf_idf[count][0] = 0;
            }
            
            count++;                
            
            if(count==map.size())
            {
                query_mag=  Math.sqrt(query_mag);
            }
        }
        for(int k=0;k<50;k++)
        {
            magnitude[k] =  Math.sqrt(magnitude[k]);
            magnitude[k]*=query_mag;
        }
        double[] sum=new double[50];
        int countdoc=0;
        HashMap<Integer,Double> score=new HashMap<Integer,Double>();
        for(int i=0;i<50;i++)
        {
            for(int j=0;j<count;j++)
            {
                if(query_tf_idf[j][0]!=0 && tf_cross_idf[j][i]!=0)//Multiply each Component of Query With Documnet 
                sum[i]+= (query_tf_idf[j][0]* tf_cross_idf[j][i]);
            }
            sum[i]/=magnitude[i];
            if(sum[i]!=0 && sum[i]>alpha)   
            {
                score.put(i+1, sum[i]);
                countdoc++;
            }
        }
        System.out.println("\n\n-----------------------------------------------");
        System.out.println("FOLLOWING ARE THE DOCUMENTS RELATED WITH QUERY.");
        System.out.println("-----------------------------------------------\n");
        score=sortscore(score);
        int loop=10,l=0;
        for(Map.Entry entry:score.entrySet()){
            loop--;
            l++;
            System.out.println("Doc No: "+entry.getKey() +" --  Score: "+entry.getValue());
            if(loop==0)
                break;
            
        }System.out.println("\n--------------------------");
        System.out.println("Total Docs Retrieved: "+ l);
        System.out.println("--------------------------");

    }


public static double finddf(String str,Map<String ,int[][]> map)//Function to find DOC FREQUENCY
  {
      int df=0;
      int[][] arr=map.get(str);
      for(int i=0;i<50;i++){
            if(arr[i][0]!=0){
              df++;
            }
      }
      return df;
  }


public static HashMap<Integer,Double> sortscore(HashMap<Integer,Double> hm) //HashMap Sorting...
    {  
        List<Map.Entry<Integer,Double> > l =new LinkedList<Map.Entry<Integer,Double> >(hm.entrySet()); 
        Collections.sort(l, new Comparator<Map.Entry<Integer,Double> >() 
        {
            public int compare(Map.Entry<Integer,Double> num1, Map.Entry<Integer,Double> num2) 
            { 
                return (num2.getValue()).compareTo(num1.getValue());
            }
        }); 
        HashMap<Integer,Double> temp = new LinkedHashMap<Integer,Double>(); 
        for (Map.Entry<Integer,Double> aa : l) { 
            temp.put(aa.getKey(), aa.getValue()); 
        } 
        return temp; 
    }
}